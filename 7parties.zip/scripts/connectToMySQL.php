<?php
  $link = mysqli_connect("localhost", "root", "root", "meetr") or die (mysqli_error());
?>